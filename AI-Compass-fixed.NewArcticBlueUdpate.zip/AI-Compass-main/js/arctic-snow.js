/* =========================================================
   AI COMPASS — ARCTIC SNOW
   A few slowly falling snowflakes on <canvas id="arctic-snow">, only while
   the Arctic Blue palette is on (css/arctic-blue.css shows the canvas only
   then, and only with "Extra effects" on and motion allowed).
   It draws nothing and runs no timer otherwise, stops while the tab is
   hidden, and never takes a click (pointer-events: none).
   ========================================================= */
(function () {
    "use strict";

    const A = window.AICompass;
    const canvas = document.getElementById("arctic-snow");
    if (!A || !canvas || !canvas.getContext) return;

    const root = document.documentElement;
    const g = canvas.getContext("2d");
    let flakes = [];
    let width = 0;
    let height = 0;
    let ratio = 1;
    let frame = 0;
    let last = 0;

    function wanted() {
        return root.getAttribute("data-palette") === "arctic"
            && root.classList.contains("fx-fancy")
            && A.motion.ok()
            && !document.hidden;
    }

    function resize() {
        ratio = Math.min(window.devicePixelRatio || 1, 2);
        width = canvas.clientWidth;
        height = canvas.clientHeight;
        canvas.width = Math.max(1, Math.round(width * ratio));
        canvas.height = Math.max(1, Math.round(height * ratio));
        g.setTransform(ratio, 0, 0, ratio, 0, 0);
        // About one flake per 18,000 px² of screen, at most 90 (fewer on phones)
        const count = Math.min(90, Math.round(width * height / 18000));
        flakes = [];
        for (let i = 0; i < count; i++) flakes.push(makeFlake(true));
    }

    function makeFlake(anywhere) {
        return {
            x: Math.random() * width,
            y: anywhere ? Math.random() * height : -10,
            r: 0.8 + Math.random() * 2.2,
            speed: 14 + Math.random() * 28,           // px per second
            drift: Math.random() * Math.PI * 2,
            sway: 8 + Math.random() * 14,
            alpha: 0.35 + Math.random() * 0.5
        };
    }

    function colour() {
        // Pale ice in the night; a soft blue in the day, where white would vanish
        return A.theme === "light" ? "40, 120, 190" : "225, 245, 255";
    }

    function draw(time) {
        frame = 0;
        if (!wanted()) { g.clearRect(0, 0, width, height); return; }
        const dt = Math.min((time - (last || time)) / 1000, 0.05);
        last = time;
        const rgb = colour();
        g.clearRect(0, 0, width, height);
        for (const f of flakes) {
            f.y += f.speed * dt;
            f.drift += dt * 0.8;
            f.x += Math.sin(f.drift) * f.sway * dt;
            if (f.y > height + 10) Object.assign(f, makeFlake(false));
            if (f.x < -10) f.x = width + 10;
            if (f.x > width + 10) f.x = -10;
            g.fillStyle = "rgba(" + rgb + "," + f.alpha + ")";
            g.beginPath();
            g.arc(f.x, f.y, f.r, 0, Math.PI * 2);
            g.fill();
        }
        frame = requestAnimationFrame(draw);
    }

    function refresh() {
        if (wanted()) {
            if (!flakes.length || canvas.clientWidth !== width) resize();
            if (!frame) { last = 0; frame = requestAnimationFrame(draw); }
        } else if (frame) {
            cancelAnimationFrame(frame);
            frame = 0;
            g.clearRect(0, 0, width, height);
        }
    }

    document.addEventListener("aic:palette", refresh);
    document.addEventListener("aic:theme", refresh);
    document.addEventListener("aic:motion", refresh);
    document.addEventListener("aic:settings", refresh);       // "Extra effects" switched on or off
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("resize", A.util.debounce(function () {
        if (wanted()) resize();
    }, 200));
    // Settings (js/settings.js) set the fx-fancy class a little after start-up
    new MutationObserver(refresh).observe(root, { attributes: true, attributeFilter: ["class", "data-palette"] });

    refresh();
})();
