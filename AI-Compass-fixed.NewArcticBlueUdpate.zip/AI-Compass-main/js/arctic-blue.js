/* =========================================================
   AI COMPASS — ARCTIC BLUE PALETTE (the switch)
   Turns the Arctic Blue palette (css/arctic-blue.css) on and off.
   The palette is independent from Day / Night: <html> has
   data-theme="dark|light" (core.js) AND, when it is on,
   data-palette="arctic" (this file). It is saved as "aic:palette".
   The small script in the <head> of index.html restores it before the
   first paint; this file keeps the buttons ([data-arctic-toggle]), the
   colour of the phone's address bar and the canvases in step with it.
   ========================================================= */
(function () {
    "use strict";

    const A = window.AICompass;
    if (!A) return;                                   // core.js failed to load

    const root = document.documentElement;
    const KEY = "palette";                            // saved as "aic:palette"
    const NAME = "arctic";

    // Colour of the address bar: [night, day] for Arctic Blue (--bg of css/arctic-blue.css)
    const BAR = { dark: "#04101c", light: "#eef7fd" };

    function isOn() {
        return root.getAttribute("data-palette") === NAME;
    }

    // The two <meta name="theme-color"> tags carry data-dark / data-light, which core.js
    // reads on every theme change. Keep the originals, and swap them while the palette is on.
    function updateBar() {
        document.querySelectorAll('meta[name="theme-color"]').forEach(function (meta) {
            ["dark", "light"].forEach(function (mode) {
                const original = "data-" + mode + "-original";
                if (!meta.hasAttribute(original)) meta.setAttribute(original, meta.getAttribute("data-" + mode) || "");
                meta.setAttribute("data-" + mode, isOn() ? BAR[mode] : meta.getAttribute(original));
            });
            const shown = root.getAttribute("data-theme") === "light" ? "light" : "dark";
            meta.setAttribute("content", meta.getAttribute("data-" + shown));
        });
    }

    function updateButtons() {
        document.querySelectorAll("[data-arctic-toggle]").forEach(function (button) {
            button.setAttribute("aria-pressed", isOn() ? "true" : "false");
        });
    }

    function setPalette(on, quiet) {
        on = on === true;
        const changed = on !== isOn();
        if (on) {
            root.setAttribute("data-palette", NAME);
            A.storage.set(KEY, NAME);
        } else {
            root.removeAttribute("data-palette");
            A.storage.remove(KEY);
        }
        updateButtons();
        updateBar();
        if (!changed) return;
        // Canvases (neural background, AI Lab) redraw on the "theme" event. Nothing else
        // listens to it with a side effect, and no progress event (track) is sent.
        document.dispatchEvent(new CustomEvent("aic:palette", { detail: { palette: on ? NAME : "default" } }));
        A.emit("theme", { theme: A.theme, palette: on ? NAME : "default" });
        if (!quiet && A.announce) {
            A.announce(on ? "Arctic Blue on. Арктический синий включён." : "Arctic Blue off. Арктический синий выключен.");
        }
    }

    function toggle() {
        setPalette(!isOn());
    }

    // The buttons: one click handler for all of them (the menu bar and the phone menu)
    document.addEventListener("click", function (event) {
        const button = event.target.closest && event.target.closest("[data-arctic-toggle]");
        if (!button) return;
        event.preventDefault();
        toggle();
    });

    // Another tab changed it
    window.addEventListener("storage", function (event) {
        if (event.key !== "aic:" + KEY) return;
        setPalette(A.storage.get(KEY, null) === NAME, true);
    });

    // The saved choice (the <head> script has already set the attribute; this also covers
    // a browser where it could not read the storage then, and syncs buttons and address bar)
    setPalette(A.storage.get(KEY, null) === NAME, true);

    // After a Day / Night switch core.js writes the address-bar colour from data-dark / data-light:
    // those hold the palette's colours now, so nothing more to do. Buttons can be built later
    // (the phone menu), so sync them once the page is ready.
    A.ready(updateButtons);

    A.palette = { get on() { return isOn(); }, set: setPalette, toggle: toggle };
})();
